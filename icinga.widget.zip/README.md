# uebersicht widet icinga
Monitor your icinga host on your desktop

## Screenshot
![Screenshot](screenshot.png?raw=true "Screenshot")

## Installation
- Download the 'uebersicht-icinga.zip' and move it to your widgets folder (default: ~/Library/Application Support/Übersicht/widgets).
- Open icinga.coffee and change the config values